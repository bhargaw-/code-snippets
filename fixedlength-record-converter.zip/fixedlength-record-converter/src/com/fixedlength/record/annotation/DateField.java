package com.fixedlength.record.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface DateField {

    String DATE = "yyyy-MM-dd";
    String DATE_TIME = "yyyy-MM-dd HH:mm:ss";
    String TIMESTAMP = "yyyy-MM-dd";

    int position();

    int length();

    Align align() default Align.LEFT;

    String format() default DATE;
}
