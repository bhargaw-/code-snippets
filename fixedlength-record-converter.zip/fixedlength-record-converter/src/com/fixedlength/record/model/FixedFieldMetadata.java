package com.fixedlength.record.model;


import com.fixedlength.record.annotation.Align;

public abstract class FixedFieldMetadata {
    private final int position;
    private final int length;
    private final Align align;
    private String fieldName;
    private String readMethod;
    private String writeMethod;
    private Class<?> type;

    public FixedFieldMetadata(int position, int length, Align align) {
        this.position = position;
        this.length = length;
        this.align = align;
    }

    public int getPosition() {
        return position;
    }

    public int getLength() {
        return length;
    }

    public Align getAlign() {
        return align;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public String getReadMethod() {
        return readMethod;
    }

    public void setReadMethod(String readMethod) {
        this.readMethod = readMethod;
    }

    public String getWriteMethod() {
        return writeMethod;
    }

    public void setWriteMethod(String writeMethod) {
        this.writeMethod = writeMethod;
    }

    public Class<?> getType() {
        return type;
    }

    public void setType(Class<?> type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "FixedFieldMetadata{" +
                "align=" + align +
                ", position=" + position +
                ", length=" + length +
                ", readMethod='" + readMethod + '\'' +
                ", writeMethod='" + writeMethod + '\'' +
                ", type='" + type + '\'' +
                '}';
    }
}
