package com.fixedlength.record.model;


import com.fixedlength.record.annotation.Align;

public class StringFieldMetadata extends FixedFieldMetadata {

    public StringFieldMetadata(int position, int length, Align align) {
        super(position, length, align);
    }
}
