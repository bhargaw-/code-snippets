package com.fixedlength.record.model;

import com.fixedlength.record.annotation.Align;

public class BooleanFieldMetadata extends FixedFieldMetadata {

    private String trueValue;
    private String falseValue;

    public BooleanFieldMetadata(int position, int length, Align align) {
        super(position, length, align);
    }

    public String getTrueValue() {
        return trueValue;
    }

    public void setTrueValue(String trueValue) {
        this.trueValue = trueValue;
    }

    public String getFalseValue() {
        return falseValue;
    }

    public void setFalseValue(String falseValue) {
        this.falseValue = falseValue;
    }


}
