package com.fixedlength.record.model;

import java.util.List;
import java.util.function.Supplier;

public class FixedRecordMetadata<T> {
    private final String header;
    private final String data;
    private final String tail;
    private final String delimiter;
    private final char padding;
    private final Class<T> aClass;
    private final List<Supplier<FixedFieldMetadata>> fieldsMetadata;

    public FixedRecordMetadata(String header, String data, String tail,
                               String delimiter, char padding, Class<T> aClass, List<Supplier<FixedFieldMetadata>> fieldsMetadata) {
        this.header = header;
        this.data = data;
        this.tail = tail;
        this.delimiter = delimiter;
        this.padding = padding;
        this.aClass = aClass;
        this.fieldsMetadata = fieldsMetadata;
    }

    public String getHeader() {
        return header;
    }

    public String getData() {
        return data;
    }

    public String getTail() {
        return tail;
    }

    public String getDelimiter() {
        return delimiter;
    }

    public char getPadding() {
        return padding;
    }

    public Class<T> getaClass() {
        return aClass;
    }

    public List<Supplier<FixedFieldMetadata>> getFieldsMetadata() {
        return fieldsMetadata;
    }

    @Override
    public String toString() {
        return "FixedRecordMetadata{" +
                "header='" + header + '\'' +
                ", data='" + data + '\'' +
                ", tail='" + tail + '\'' +
                ", delimiter='" + delimiter + '\'' +
                ", padding='" + padding + '\'' +
                ", aClass=" + aClass +
                ", fieldsMetadata=" + fieldsMetadata +
                '}';
    }
}
