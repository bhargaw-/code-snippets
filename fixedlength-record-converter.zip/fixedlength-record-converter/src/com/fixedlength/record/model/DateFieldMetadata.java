package com.fixedlength.record.model;


import com.fixedlength.record.annotation.Align;

public class DateFieldMetadata extends FixedFieldMetadata {

    private String format;

    public DateFieldMetadata(int position, int length, Align align) {
        super(position, length, align);
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }
}
