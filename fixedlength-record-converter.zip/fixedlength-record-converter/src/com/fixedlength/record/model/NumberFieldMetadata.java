package com.fixedlength.record.model;


import com.fixedlength.record.annotation.Align;

public class NumberFieldMetadata extends FixedFieldMetadata {
    private int decimals;
    private String decimalDelimiter;
    private int roundingMode;

    public NumberFieldMetadata(int position, int length, Align align) {
        super(position, length, align);
    }
    public int getDecimals() {
        return decimals;
    }

    public void setDecimals(int decimals) {
        this.decimals = decimals;
    }

    public String getDecimalDelimiter() {
        return decimalDelimiter;
    }

    public void setDecimalDelimiter(String decimalDelimiter) {
        this.decimalDelimiter = decimalDelimiter;
    }

    public int getRoundingMode() {
        return roundingMode;
    }

    public void setRoundingMode(int roundingMode) {
        this.roundingMode = roundingMode;
    }
}
