package com.fixedlength.record.converter;


import com.fixedlength.record.model.FixedFieldMetadata;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

public class ObjectToStringConversionService {

    private static ConverterFunction<Boolean, FixedFieldMetadata, String> booleanToStringConverter() {
        return (t, fieldMetadata) -> t == null ? null : t.toString();
    }

    private static ConverterFunction<Byte, FixedFieldMetadata, String> byteToStringConverter() {
        return (t, fieldMetadata) -> t == null ? null : t.toString();
    }

    private static ConverterFunction<Short, FixedFieldMetadata, String> shortToStringConverter() {
        return (t, fieldMetadata) -> t == null ? null : t.toString();
    }

    private static ConverterFunction<Integer, FixedFieldMetadata, String> intToStringConverter() {
        return (t, fieldMetadata) -> t == null ? null : t.toString();
    }

    private static ConverterFunction<Long, FixedFieldMetadata, String> longToStringConverter() {
        return (t, fieldMetadata) -> t == null ? null : t.toString();
    }

    private static ConverterFunction<Float, FixedFieldMetadata, String> floatToStringConverter() {
        return (t, fieldMetadata) -> t == null ? null : t.toString();
    }

    private static ConverterFunction<Double, FixedFieldMetadata, String> doubleToStringConverter() {
        return (t, fieldMetadata) -> t == null ? null : t.toString();
    }

    private static ConverterFunction<BigDecimal, FixedFieldMetadata, String> bigDecimalToStringConverter() {
        return (t, fieldMetadata) -> t == null ? null : t.toString();
    }

    private static ConverterFunction<String, FixedFieldMetadata, String> stringToStringConverter() {
        return (t, fieldMetadata) -> t;
    }

    private static ConverterFunction<Date, FixedFieldMetadata, String> utilDateToStringConverter() {
        return (t, fieldMetadata) -> t == null ? null : t.toString();
    }

    private static ConverterFunction<LocalDate, FixedFieldMetadata, String> localDateToStringConverter() {
        return (t, fieldMetadata) -> t == null ? null : t.toString();
    }

    private static ConverterFunction<LocalDateTime, FixedFieldMetadata, String> localDateTimeToStringConverter() {
        return (t, fieldMetadata) -> t == null ? null : t.toString();
    }

    public Map<Class<?>, ConverterFunction<?, FixedFieldMetadata, String>> loadConverters() {
        final Map<Class<?>, ConverterFunction<?, FixedFieldMetadata, String>> objectToStringConverterInstances =
                new LinkedHashMap<>();
        objectToStringConverterInstances.put(boolean.class, booleanToStringConverter());
        objectToStringConverterInstances.put(Boolean.class, booleanToStringConverter());
        objectToStringConverterInstances.put(byte.class, byteToStringConverter());
        objectToStringConverterInstances.put(Byte.class, byteToStringConverter());
        objectToStringConverterInstances.put(short.class, shortToStringConverter());
        objectToStringConverterInstances.put(Short.class, shortToStringConverter());
        objectToStringConverterInstances.put(int.class, intToStringConverter());
        objectToStringConverterInstances.put(Integer.class, intToStringConverter());
        objectToStringConverterInstances.put(long.class, longToStringConverter());
        objectToStringConverterInstances.put(Long.class, longToStringConverter());
        objectToStringConverterInstances.put(float.class, floatToStringConverter());
        objectToStringConverterInstances.put(Float.class, floatToStringConverter());
        objectToStringConverterInstances.put(double.class, doubleToStringConverter());
        objectToStringConverterInstances.put(Double.class, doubleToStringConverter());
        objectToStringConverterInstances.put(BigDecimal.class, bigDecimalToStringConverter());
        objectToStringConverterInstances.put(String.class, stringToStringConverter());
        objectToStringConverterInstances.put(Date.class, utilDateToStringConverter());
        objectToStringConverterInstances.put(LocalDate.class, localDateToStringConverter());
        objectToStringConverterInstances.put(LocalDateTime.class, localDateTimeToStringConverter());
        return objectToStringConverterInstances;
    }
}
