package com.fixedlength.record.converter;

import com.fixedlength.record.model.DateFieldMetadata;
import com.fixedlength.record.model.FixedFieldMetadata;
import com.fixedlength.record.util.StringUtil;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

public class StringToObjectConversionService {

    private ConverterFunction<String, FixedFieldMetadata, Boolean> stringToBooleanConverter() {
        return (t, fieldMetadata) -> StringUtil.isEmpty(t) ? null : Boolean.parseBoolean(t);
    }

    private ConverterFunction<String, FixedFieldMetadata, Byte> stringToByteConverter() {
        return (t, fieldMetadata) -> StringUtil.isEmpty(t) ? null : Byte.parseByte(t);
    }

    private ConverterFunction<String, FixedFieldMetadata, Short> stringToShortConverter() {
        return (t, fieldMetadata) -> StringUtil.isEmpty(t) ? null : Short.parseShort(t);
    }

    private ConverterFunction<String, FixedFieldMetadata, Integer> stringToIntegerConverter() {
        return (t, fieldMetadata) -> StringUtil.isEmpty(t) ? null : Integer.parseInt(t);
    }

    private ConverterFunction<String, FixedFieldMetadata, Long> stringToLongConverter() {
        return (t, fieldMetadata) -> StringUtil.isEmpty(t) ? null : Long.parseLong(t);
    }

    private ConverterFunction<String, FixedFieldMetadata, Float> stringToFloatConverter() {
        return (t, fieldMetadata) -> StringUtil.isEmpty(t) ? null : Float.parseFloat(t);
    }

    private ConverterFunction<String, FixedFieldMetadata, Double> stringToDoubleConverter() {
        return (t, fieldMetadata) -> StringUtil.isEmpty(t) ? null : Double.parseDouble(t);
    }

    private ConverterFunction<String, FixedFieldMetadata, BigDecimal> stringToBigDecimalConverter() {
        return (t, fieldMetadata) -> StringUtil.isEmpty(t) ? null : new BigDecimal(t);
    }

    private ConverterFunction<String, FixedFieldMetadata, String> stringToStringConverter() {
        return (t, fieldMetadata) -> t;
    }

    private ConverterFunction<String, FixedFieldMetadata, Date> stringToUtilDateConverter() {
        return (t, fieldMetadata) -> StringUtil.isEmpty(t) ? null : new Date(t);
    }

    private ConverterFunction<String, FixedFieldMetadata, LocalDate> stringToLocalDateConverter() {
        return (t, fieldMetadata) -> StringUtil.isEmpty(t) ? null : LocalDate.parse(t,
                DateTimeFormatter.ofPattern(((DateFieldMetadata) fieldMetadata).getFormat()));
    }

    private ConverterFunction<String, FixedFieldMetadata, LocalDateTime> stringToLocalDateTimeConverter() {
        return (t, fieldMetadata) -> StringUtil.isEmpty(t) ? null : LocalDateTime.parse(t,
                DateTimeFormatter.ofPattern(((DateFieldMetadata) fieldMetadata).getFormat()));
    }

    public Map<Class<?>, ConverterFunction<String, FixedFieldMetadata, ?>> loadConverters() {
        final Map<Class<?>, ConverterFunction<String, FixedFieldMetadata, ?>>
                stringToObjectConverterInstances = new LinkedHashMap<>();
        stringToObjectConverterInstances.put(boolean.class, stringToBooleanConverter());
        stringToObjectConverterInstances.put(Boolean.class, stringToBooleanConverter());
        stringToObjectConverterInstances.put(byte.class, stringToByteConverter());
        stringToObjectConverterInstances.put(Byte.class, stringToByteConverter());
        stringToObjectConverterInstances.put(short.class, stringToShortConverter());
        stringToObjectConverterInstances.put(Short.class, stringToShortConverter());
        stringToObjectConverterInstances.put(int.class, stringToIntegerConverter());
        stringToObjectConverterInstances.put(Integer.class, stringToIntegerConverter());
        stringToObjectConverterInstances.put(long.class, stringToLongConverter());
        stringToObjectConverterInstances.put(Long.class, stringToLongConverter());
        stringToObjectConverterInstances.put(float.class, stringToFloatConverter());
        stringToObjectConverterInstances.put(Float.class, stringToFloatConverter());
        stringToObjectConverterInstances.put(double.class, stringToDoubleConverter());
        stringToObjectConverterInstances.put(Double.class, stringToDoubleConverter());
        stringToObjectConverterInstances.put(BigDecimal.class, stringToBigDecimalConverter());
        stringToObjectConverterInstances.put(String.class, stringToStringConverter());
        stringToObjectConverterInstances.put(Date.class, stringToUtilDateConverter());
        stringToObjectConverterInstances.put(LocalDate.class, stringToLocalDateConverter());
        stringToObjectConverterInstances.put(LocalDateTime.class, stringToLocalDateTimeConverter());

        return stringToObjectConverterInstances;
    }
}
