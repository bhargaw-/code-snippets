package com.fixedlength.record.converter;

import com.fixedlength.record.model.FixedFieldMetadata;

@FunctionalInterface
public interface ConverterFunction<T, K extends FixedFieldMetadata, R> {
    R convert(T t, K k);
}
