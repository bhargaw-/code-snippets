package com.fixedlength.record.service;

import com.fixedlength.record.converter.ConverterFunction;
import com.fixedlength.record.converter.ObjectToStringConversionService;
import com.fixedlength.record.converter.StringToObjectConversionService;
import com.fixedlength.record.exception.ConverterException;
import com.fixedlength.record.model.FixedFieldMetadata;
import com.fixedlength.record.model.FixedRecordMetadata;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.fixedlength.record.service.FixedRecordMetadataService.validate;

public class FixedRecordConverterService<T> {

    private final FixedRecordMetadata<T> FIXED_RECORD_METADATA;
    private final Map<String, ConverterFunction<?, FixedFieldMetadata, String>> CUSTOM_CONVERT_TO_STRING_FUNCTIONS;
    private final Map<String, ConverterFunction<String, FixedFieldMetadata, ?>> CUSTOM_CONVERT_TO_OBJECT_FUNCTIONS;
    private final Class<T> classType;
    private Map<Class<?>, ConverterFunction<?, FixedFieldMetadata, String>> CONVERT_TO_STRING_FUNCTIONS =
            Collections.emptyMap();
    private Map<Class<?>, ConverterFunction<String, FixedFieldMetadata, ?>> CONVERT_TO_OBJECT_FUNCTIONS =
            Collections.emptyMap();

    public FixedRecordConverterService(Class<T> fixedRecordClass) {
        validate(fixedRecordClass, "Unable to parse the class. It is null");
        FIXED_RECORD_METADATA = new FixedRecordMetadataService().loadMetadata(fixedRecordClass);
        this.classType = fixedRecordClass;
        CUSTOM_CONVERT_TO_STRING_FUNCTIONS = new LinkedHashMap<>();
        CUSTOM_CONVERT_TO_OBJECT_FUNCTIONS = new LinkedHashMap<>();
    }

    public FixedRecordMetadata<T> getMetadata() {
        return this.FIXED_RECORD_METADATA;
    }

    public String convertObjectToString(T t) {
        validate(t, "target object should not be null");
        loadObjectToStringConverterFunctions();
        try {
            return FIXED_RECORD_METADATA.getFieldsMetadata().stream()
                    .map(Supplier::get)
                    .map(abstractFieldMetadata -> objectToStringConverter(
                            t, abstractFieldMetadata.getType(), abstractFieldMetadata))
                    .collect(Collectors.joining());
        } finally {
            CONVERT_TO_STRING_FUNCTIONS.clear();
            CUSTOM_CONVERT_TO_STRING_FUNCTIONS.clear();
        }
    }

    public T convertStringToObject(String fixedString) {
        validate(fixedString, "target string is should not be null");
        T t = instantiateClass();
        loadStringToObjectConverterFunctions();
        try {
            FIXED_RECORD_METADATA.getFieldsMetadata()
                    .stream()
                    .map(Supplier::get)
                    .forEach(metadata -> setData(fixedString, t, metadata));
        } finally {
            CONVERT_TO_OBJECT_FUNCTIONS.clear();
            CUSTOM_CONVERT_TO_OBJECT_FUNCTIONS.clear();
        }
        return t;
    }

    public void addObjectToStringConverterFunction(final String propertyName,
                                                   final ConverterFunction<?, FixedFieldMetadata, String> converterFunction) {
        validate(converterFunction, "Converter function must not be null");
        CUSTOM_CONVERT_TO_STRING_FUNCTIONS.put(propertyName, converterFunction);
    }

    public void addStringToObjectConverterFunction(final String propertyName,
                                                   final ConverterFunction<String, FixedFieldMetadata, ?> converterFunction) {
        validate(converterFunction, "Converter function must not be null");
        CUSTOM_CONVERT_TO_OBJECT_FUNCTIONS.put(propertyName, converterFunction);
    }

    private void setData(String paddedString, T t, FixedFieldMetadata metadata) {
        ConverterFunction<String, FixedFieldMetadata, ?> converterFunction =
                getStringToObjectConverterFunction(metadata.getFieldName(), metadata.getType());
        try {
            String valueString = metadata.getAlign()
                    .apply(paddedString, metadata.getLength(), FIXED_RECORD_METADATA.getPadding());
            Method method = t.getClass().getMethod(metadata.getWriteMethod(), metadata.getType());
            method.invoke(t, converterFunction.convert(valueString, metadata));
        } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
            throw new ConverterException("Unable to set data to target object : " + t.getClass(), e);
        }
    }


    @SuppressWarnings({"unchecked", "rawtype"})
    private <K> String objectToStringConverter(T t, Class<K> type, FixedFieldMetadata metadata) {
        K propertyValue = (K) readPropertyValue(metadata.getReadMethod(), t);
        ConverterFunction<K, FixedFieldMetadata, String> converterFunction =
                (ConverterFunction<K, FixedFieldMetadata, String>)
                        getObjectToStringConverterFunction(metadata.getFieldName(), type);
        String result = converterFunction.convert(propertyValue, metadata);
        return metadata.getAlign().apply(result, metadata.getLength(), FIXED_RECORD_METADATA.getPadding());
    }

    private Object readPropertyValue(String methodName, T t) {
        try {
            Method method = t.getClass().getMethod(methodName);
            return method.invoke(t);
        } catch (Exception e) {
            throw new ConverterException(e.getLocalizedMessage(), e);
        }
    }

    @SuppressWarnings("unchecked")
    private T instantiateClass() {
        return (T) Stream.of(this.classType.getDeclaredConstructors())
                .filter(constructor -> constructor.getParameterCount() == 0)
                .findAny()
                .map(FixedRecordConverterService::instantiateClass)
                .orElseThrow(() -> new ConverterException("No zero argument constructor is found."));
    }

    private static <T> T instantiateClass(Constructor<T> ctor) {
        try {
            return ctor.newInstance();
        } catch (InstantiationException var6) {
            throw new ConverterException("Is it an abstract class?", var6);
        } catch (IllegalAccessException var7) {
            throw new ConverterException("Is the constructor accessible?", var7);
        } catch (IllegalArgumentException var8) {
            throw new ConverterException("Illegal arguments for constructor", var8);
        } catch (InvocationTargetException var9) {
            throw new ConverterException("Constructor threw exception", var9.getTargetException());
        }
    }

    private ConverterFunction<?, FixedFieldMetadata, String> getObjectToStringConverterFunction(
            String fieldName, Class<?> kClass) {
        ConverterFunction<?, FixedFieldMetadata, String> function =
                this.CUSTOM_CONVERT_TO_STRING_FUNCTIONS.get(fieldName);
        if (function == null) {
            function = this.CONVERT_TO_STRING_FUNCTIONS.get(kClass);
        }
        validate(function, String.format("No suitable converter function found for given field [%s] or class [%s]",
                fieldName, kClass));
        return function;
    }

    private ConverterFunction<String, FixedFieldMetadata, ?> getStringToObjectConverterFunction(
            String fieldName, Class<?> kClass) {
        ConverterFunction<String, FixedFieldMetadata, ?> function =
                this.CUSTOM_CONVERT_TO_OBJECT_FUNCTIONS.get(fieldName);
        if (function == null) {
            function = this.CONVERT_TO_OBJECT_FUNCTIONS.get(kClass);
        }
        validate(function, String.format("No suitable converter function found for given field [%s] or class [%s]",
                fieldName, kClass));
        return function;
    }

    private void loadObjectToStringConverterFunctions() {
        if (CONVERT_TO_STRING_FUNCTIONS.isEmpty()) {
            synchronized (this) {
                if (CONVERT_TO_STRING_FUNCTIONS.isEmpty()) {
                    CONVERT_TO_STRING_FUNCTIONS = new ObjectToStringConversionService().loadConverters();
                }
            }
        }
    }

    private void loadStringToObjectConverterFunctions() {
        if (CONVERT_TO_OBJECT_FUNCTIONS.isEmpty()) {
            synchronized (this) {
                if (CONVERT_TO_OBJECT_FUNCTIONS.isEmpty()) {
                    CONVERT_TO_OBJECT_FUNCTIONS = new StringToObjectConversionService().loadConverters();
                }
            }
        }
    }
}
