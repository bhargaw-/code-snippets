package com.fixedlength.record.service;

import com.fixedlength.record.annotation.*;
import com.fixedlength.record.exception.ConverterException;
import com.fixedlength.record.model.*;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FixedRecordMetadataService {

    private final Map<Class<?>, Function<Field, FixedFieldMetadata>> fieldMetadataInstances = new LinkedHashMap<>();

    public <T> FixedRecordMetadata<T> loadMetadata(Class<T> aClass) {
        validate(aClass, "Unable to load given class. null is found");
        FixedRecord fixedRecord = aClass.getAnnotation(FixedRecord.class);
        validate(fixedRecord, String.format("%s is no a FixedRecord class. " +
                "please annotate target class with @FixedRecord", aClass.getName()));
        this.init(); // load field metadata instance functions
        List<Supplier<FixedFieldMetadata>> fieldsMetadata = Stream.of(aClass.getDeclaredFields())
                .map(field -> getFieldMetadata(field, aClass))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        return new FixedRecordMetadata<>(
                fixedRecord.header(),
                fixedRecord.data(),
                fixedRecord.tail(),
                fixedRecord.delimiter(),
                fixedRecord.padding(),
                aClass,
                fieldsMetadata
        );
    }

    private Supplier<FixedFieldMetadata> getFieldMetadata(Field field, Class<?> clazz) {
        PropertyDescriptor propertyDescriptor = null;
        String propertyName = field.getName();
        try {
            propertyDescriptor = new PropertyDescriptor(propertyName, clazz);
        } catch (IntrospectionException ignored) {
        }
        if (propertyDescriptor == null) {
            return null;
        }
        Method readMethod = propertyDescriptor.getReadMethod();
        Method writeMethod = propertyDescriptor.getWriteMethod();

        if (readMethod == null || writeMethod == null) {
            return null;
        }
        Function<Field, FixedFieldMetadata> fieldMetadataFunction = this.fieldMetadataInstances.get(field.getType());
        validate(fieldMetadataFunction, String.format("Unsupported type is found on field [%s]", field.getName()));
        FixedFieldMetadata fieldMetadata = fieldMetadataFunction.apply(field);
        fieldMetadata.setFieldName(field.getName());
        fieldMetadata.setReadMethod(readMethod.getName());
        fieldMetadata.setWriteMethod(writeMethod.getName());
        fieldMetadata.setType(readMethod.getReturnType());
        return () -> fieldMetadata;
    }

    private StringFieldMetadata getStringFieldMetadata(Field field) {
        StringField stringField = field.getAnnotation(StringField.class);
        validate(stringField, String.format(
                "Misplaced annotation @StringField on field [%s] of type [%s]", field.getName(), field.getType()));
        return new StringFieldMetadata(
                stringField.position(),
                stringField.length(),
                stringField.align()
        );
    }

    private BooleanFieldMetadata getBooleanFieldMetadata(Field field) {
        BooleanField booleanField = field.getAnnotation(BooleanField.class);
        validate(booleanField, String.format(
                "Misplaced annotation @BooleanField on field [%s] of type [%s]", field.getName(), field.getType()));
        BooleanFieldMetadata booleanFieldConverter = new BooleanFieldMetadata(
                booleanField.position(),
                booleanField.length(),
                booleanField.align()
        );
        booleanFieldConverter.setFalseValue(booleanField.falseValue());
        booleanFieldConverter.setTrueValue(booleanField.trueValue());
        return booleanFieldConverter;
    }

    private NumberFieldMetadata getNumberFieldMetadata(Field field) {
        NumberField numberField = field.getAnnotation(NumberField.class);
        validate(numberField, String.format(
                "Misplaced annotation @NumberField on field [%s] of type [%s]", field.getName(), field.getType()));
        NumberFieldMetadata numberFieldMetadata = new NumberFieldMetadata(
                numberField.position(),
                numberField.length(),
                numberField.align()
        );
        numberFieldMetadata.setDecimals(numberField.decimals());
        numberFieldMetadata.setDecimalDelimiter(numberField.decimalDelimiter());
        numberFieldMetadata.setRoundingMode(numberField.roundingMode());
        return numberFieldMetadata;
    }

    private DateFieldMetadata getDateFieldMetadata(Field field) {
        DateField dateField = field.getAnnotation(DateField.class);
        validate(dateField, String.format(
                "Misplaced annotation @DateField on field [%s] of type [%s]", field.getName(), field.getType()));
        DateFieldMetadata dateFieldMetadata = new DateFieldMetadata(
                dateField.position(),
                dateField.length(),
                dateField.align()
        );
        dateFieldMetadata.setFormat(dateField.format());
        return dateFieldMetadata;
    }

    public static void validate(Object obj, String errorMessage) {
        if (obj == null) {
            throw new ConverterException(errorMessage);
        }
    }

    public void init() {
        fieldMetadataInstances.put(boolean.class, this::getBooleanFieldMetadata);
        fieldMetadataInstances.put(Boolean.class, this::getBooleanFieldMetadata);
        fieldMetadataInstances.put(byte.class, this::getNumberFieldMetadata);
        fieldMetadataInstances.put(Byte.class, this::getNumberFieldMetadata);
        fieldMetadataInstances.put(short.class, this::getNumberFieldMetadata);
        fieldMetadataInstances.put(Short.class, this::getNumberFieldMetadata);
        fieldMetadataInstances.put(int.class, this::getNumberFieldMetadata);
        fieldMetadataInstances.put(Integer.class, this::getNumberFieldMetadata);
        fieldMetadataInstances.put(long.class, this::getNumberFieldMetadata);
        fieldMetadataInstances.put(Long.class, this::getNumberFieldMetadata);
        fieldMetadataInstances.put(float.class, this::getNumberFieldMetadata);
        fieldMetadataInstances.put(Float.class, this::getNumberFieldMetadata);
        fieldMetadataInstances.put(double.class, this::getNumberFieldMetadata);
        fieldMetadataInstances.put(Double.class, this::getNumberFieldMetadata);
        fieldMetadataInstances.put(BigDecimal.class, this::getNumberFieldMetadata);
        fieldMetadataInstances.put(String.class, this::getStringFieldMetadata);
        fieldMetadataInstances.put(Date.class, this::getDateFieldMetadata);
        fieldMetadataInstances.put(LocalDate.class, this::getDateFieldMetadata);
        fieldMetadataInstances.put(LocalDateTime.class, this::getDateFieldMetadata);
    }
}
