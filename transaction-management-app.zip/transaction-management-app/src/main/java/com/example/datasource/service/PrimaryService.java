package com.example.datasource.service;

import java.util.Arrays;
import java.util.List;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.datasource.model.User;
import com.example.datasource.one.repo.PrimaryUserRepo;

@Service
public class PrimaryService {
	
	@Autowired
	private PrimaryUserRepo primaryUserRepo;
	
	@Transactional(rollbackOn = {ArithmeticException.class}, value = TxType.REQUIRES_NEW)
	public void doProcess1() {	
		
		List<User> users = Arrays.asList(new User(1, "Bhargav2", 31),
				new User(2, "Bhargav2", 32),
				new User(3, "Bhargav3", 33));
		
		users = primaryUserRepo.saveAll(users);
		
		users.forEach(System.out::println);	
		
		//throw new ArithmeticException(" This message from doprocess1()");
		
	}

}
