package com.example.datasource.one;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;


@Configuration
@Transactional
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "com.example.datasource.one.repo", 
						entityManagerFactoryRef = "primaryEntityManager", 
						transactionManagerRef = "primaryTransactionManager")
						
public class DataSourceOneConfiguration {
	
	@Primary
	@Bean("primaryDataSourceProperties")
	@ConfigurationProperties(prefix="spring.first.datasource")
	DataSourceProperties dataSourceOneProperties() {
		return new DataSourceProperties();
	}

	@Primary
	@Bean("primaryDatasource")
	DataSource dataSource() {
		return dataSourceOneProperties().initializeDataSourceBuilder().build();
	}

	@Primary
    @Bean(name = "primaryEntityManager")
	@PersistenceContext(unitName = "primary")
	LocalContainerEntityManagerFactoryBean entityManagerFactoryBean(EntityManagerFactoryBuilder builder) {
		return builder.dataSource(dataSource())
				.persistenceUnit("primary")
				.properties(jpaProperties())
				.packages("com.example.datasource.model")
				.build();
	}

	@Primary
	@Bean("primaryTransactionManager")
	PlatformTransactionManager transactionManager(
			@Qualifier("primaryEntityManager") EntityManagerFactory entityManagerFactory) {
		return new JpaTransactionManager(entityManagerFactory);
	}
	
	private Map<String, Object> jpaProperties() {
        Map<String, Object> props = new HashMap<>();
        props.put("hibernate.show_sql", true);
        props.put("hibernate.hbm2ddl.auto", "create");
        return props;
    }
	
	/*@Primary
	@Bean("primaryTransactionManager")
	PlatformTransactionManager transactionManager() {
		return new JtaTransactionManager();
	}*/
	

}
