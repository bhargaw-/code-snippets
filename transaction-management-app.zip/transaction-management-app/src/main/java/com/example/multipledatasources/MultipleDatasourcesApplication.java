package com.example.multipledatasources;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

import com.example.datasource.service.PrimaryService;

@SpringBootApplication
@ComponentScan("com.example.datasource")
@EnableAutoConfiguration(exclude = { DataSourceAutoConfiguration.class })
public class MultipleDatasourcesApplication implements CommandLineRunner{
	
	@Autowired
	private PrimaryService primaryService;	

	public static void main(String[] args) {
		SpringApplication.run(MultipleDatasourcesApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		System.out.println("Inside the run method");
		try{
			primaryService.doProcess1();
		}catch (Exception e) {
			System.out.println(e.getMessage() + " From One");
		}
		System.out.println("Execution completed");
	}	
	
}
