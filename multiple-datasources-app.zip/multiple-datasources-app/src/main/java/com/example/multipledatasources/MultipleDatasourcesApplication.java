package com.example.multipledatasources;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

import com.example.datasource.model.User;
import com.example.datasource.one.repo.PrimaryUserRepo;
import com.example.datasource.two.repo.SecondryUserRepo;

@SpringBootApplication
@ComponentScan("com.example.datasource")
@EnableAutoConfiguration(exclude = { DataSourceAutoConfiguration.class })
public class MultipleDatasourcesApplication implements CommandLineRunner{
	
	@Autowired
	private PrimaryUserRepo userRepoOne;
	
	@Autowired
	private SecondryUserRepo userRepoTwo;

	public static void main(String[] args) {
		SpringApplication.run(MultipleDatasourcesApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		System.out.println("Inside the run method");
		
		List<User> users = Arrays.asList(new User(1, "Bhargav2", 31),
				new User(2, "Bhargav2", 32),
				new User(3, "Bhargav3", 33));
		
		userRepoTwo.saveAll(userRepoOne.saveAll(users)).forEach(System.out::println);
		
		System.out.println("Execution completed");
	}
}
