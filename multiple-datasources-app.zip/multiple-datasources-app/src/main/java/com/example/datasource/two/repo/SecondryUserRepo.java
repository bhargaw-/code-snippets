package com.example.datasource.two.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.datasource.model.User;

@Repository
public interface SecondryUserRepo extends JpaRepository<User, Integer> {
	
}
