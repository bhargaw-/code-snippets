
package com.jpmc.fixed.format.converter;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.jpmc.fixed.format.annotation.exception.FormatException;
import com.jpmc.fixed.format.model.DateFieldMetadata;
import com.jpmc.fixed.format.model.FieldMetadata;
import com.jpmc.fixed.format.util.StringUtil;

public class DateConverter extends AbstractConverter<Date> {

	private DateFormat getFormatter(String pattern) {
		return new SimpleDateFormat(pattern);
	}

	@Override
	public String writeAsString(Date t, FieldMetadata fileFieldMetadata) {
		return t != null ? getFormatter(fileFieldMetadata.getDateFieldMetadata().getFormat()).format(t) : null;
	}

	@Override
	public Date writeAsObject(String t, FieldMetadata fileFieldMetadata) {
		Date result = null;

		if (!StringUtil.isEmpty(t)) {
			DateFieldMetadata dateFieldMetadata = fileFieldMetadata.getDateFieldMetadata();
			try {
				result = getFormatter(dateFieldMetadata.getFormat()).parse(t);
			} catch (ParseException e) {
				throw new FormatException("Could not parse value[" + t + "] by pattern[" + dateFieldMetadata.getFormat()
						+ "] to " + Date.class.getName());
			}
		}
		return result;
	}
}
