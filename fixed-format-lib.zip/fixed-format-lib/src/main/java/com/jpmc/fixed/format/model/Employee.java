package com.jpmc.fixed.format.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

import com.jpmc.fixed.format.annotation.DateField;
import com.jpmc.fixed.format.annotation.DecimalField;
import com.jpmc.fixed.format.annotation.Align;
import com.jpmc.fixed.format.annotation.BasicField;
import com.jpmc.fixed.format.annotation.Record;

public @Record(record = "B", delemeter = ",", footer = "T", header = "H", padding = '0') class Employee
		implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7393363906261634335L;

	@BasicField(length = 5, position = 1, startIndex = 1, padding = '0', align = Align.RIGHT)
	private int empId;

	@BasicField(length = 10, position = 2, startIndex = 6, padding = '*')
	private String empName;

	@BasicField(length = 10, position = 3, startIndex = 17)
	@DecimalField
	private float rateOfInterest;

//	@BasicField(length = 10, position = 4, startIndex = 0)
//	private double salary;
//
//	@BasicField(length = 10, position = 5, startIndex = 0)
//	private boolean active;
//
//	@BasicField(length = 10, position = 6, startIndex = 0)
//	private short deptNo;
//
//	@BasicField(length = 10, position = 7, startIndex = 0)
//	private byte loginId;
//
//	@BasicField(length = 10, position = 8, startIndex = 0)
//	@DateField(format =  DateField.SHORT)
//	private Date dob;
//
//	@BasicField(length = 10, position = 9, startIndex = 0)
//	@DateField(format =  DateField.SHORT)
//	private LocalDate joindate;
//
//	@BasicField(length = 10, position = 10, startIndex = 0)
//	@DateField(format =  DateField.SHORT)
//	private LocalDateTime loginTime;
//
//	@BasicField(length = 10, position = 11, startIndex = 0)
//	private BigDecimal convertor;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public float getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(float rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}

//	public double getSalary() {
//		return salary;
//	}
//
//	public void setSalary(double salary) {
//		this.salary = salary;
//	}
//
//	public boolean isActive() {
//		return active;
//	}
//
//	public void setActive(boolean active) {
//		this.active = active;
//	}
//
//	public short getDeptNo() {
//		return deptNo;
//	}
//
//	public void setDeptNo(short deptNo) {
//		this.deptNo = deptNo;
//	}
//
//	public byte getLoginId() {
//		return loginId;
//	}
//
//	public void setLoginId(byte loginId) {
//		this.loginId = loginId;
//	}
//
//	public Date getDob() {
//		return dob;
//	}
//
//	public void setDob(Date dob) {
//		this.dob = dob;
//	}
//
//	public LocalDate getJoindate() {
//		return joindate;
//	}
//
//	public void setJoindate(LocalDate joindate) {
//		this.joindate = joindate;
//	}
//
//	public LocalDateTime getLoginTime() {
//		return loginTime;
//	}
//
//	public void setLoginTime(LocalDateTime loginTime) {
//		this.loginTime = loginTime;
//	}
//
//	public BigDecimal getConvertor() {
//		return convertor;
//	}
//
//	public void setConvertor(BigDecimal convertor) {
//		this.convertor = convertor;
//	}

}
