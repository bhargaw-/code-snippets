package com.jpmc.fixed.format.converter;

import com.jpmc.fixed.format.model.FieldMetadata;

public class IntegerConverter extends AbstractConverter<Integer> {

	@Override
	public String writeAsString(Integer t, FieldMetadata fileFieldMetadata) {
		return t != null ? Integer.toString(t) : null;
	}

	@Override
	public Integer writeAsObject(String t, FieldMetadata fileFieldMetadata) {
		return Integer.parseInt(t);
	}
}
