package com.jpmc.fixed.format.converter;

import com.jpmc.fixed.format.model.FieldMetadata;

public class ShortConverter extends AbstractConverter<Short> {

	@Override
	public String writeAsString(Short t, FieldMetadata fileFieldMetadata) {
		return t != null ? Short.toString(t) : null;
	}

	@Override
	public Short writeAsObject(String t, FieldMetadata fileFieldMetadata) {
		return Short.parseShort(t);
	}
}
