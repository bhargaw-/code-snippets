package com.jpmc.fixed.format.converter;

import java.math.BigDecimal;

import com.jpmc.fixed.format.model.FieldMetadata;

public class BigDecimalConverter extends DecimalConverter<BigDecimal> {

	@Override
	public BigDecimal writeAsObject(String t, FieldMetadata fileFieldMetadata) {
		String toConvert = getNumberStrig(t, fileFieldMetadata.getDecimalFieldMetadata());
		return new BigDecimal("".equals(toConvert) ? "0" : toConvert);
	}
}
