
package com.jpmc.fixed.format.converter;

import com.jpmc.fixed.format.model.FieldMetadata;

public class FloatConverter extends DecimalConverter<Float> {

	@Override
	public Float writeAsObject(String t, FieldMetadata fileFieldMetadata) {
		String toConvert = getNumberStrig(t, fileFieldMetadata.getDecimalFieldMetadata());
		return Float.parseFloat("".equals(toConvert) ? "0" : toConvert);
	}

}
