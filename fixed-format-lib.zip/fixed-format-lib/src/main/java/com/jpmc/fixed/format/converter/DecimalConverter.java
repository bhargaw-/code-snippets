package com.jpmc.fixed.format.converter;

import java.math.BigDecimal;
import java.math.MathContext;
import java.text.DecimalFormat;

import com.jpmc.fixed.format.model.DecimalFieldMetadata;
import com.jpmc.fixed.format.model.FieldMetadata;
import com.jpmc.fixed.format.util.StringUtil;

public abstract class DecimalConverter<T extends Number> extends AbstractConverter<T> {

//	 private static final Log LOG = LogFactory.getLog(AbstractDecimalFormatter.class);

	public String numberToString(Number obj, DecimalFieldMetadata decimalFieldMetadata) {
		if (decimalFieldMetadata == null) {
			return obj == null ? null : obj.toString();
		}
		BigDecimal roundedValue = null;
		int decimals = decimalFieldMetadata.getDecimals();
		if (obj != null) {
			BigDecimal value = obj instanceof BigDecimal ? (BigDecimal) obj : BigDecimal.valueOf(obj.doubleValue());
			MathContext roundingMode = new MathContext(decimalFieldMetadata.getRoundingMode());
			roundedValue = value.round(roundingMode);

//	      if (LOG.isDebugEnabled()) {
//	        LOG.debug("Value before rounding = '" + value + "', value after rounding = '" + roundedValue + "', decimals = " + decimals + ", rounding mode = " + roundingMode);
//	      }
		}

		DecimalFormat formatter = new DecimalFormat();
		formatter.setDecimalSeparatorAlwaysShown(true);
		formatter.setMaximumFractionDigits(decimals);

		char decimalSeparator = formatter.getDecimalFormatSymbols().getDecimalSeparator();
		char groupingSeparator = formatter.getDecimalFormatSymbols().getGroupingSeparator();
		String zeroString = "0" + decimalSeparator + "0";

		String rawString = roundedValue != null ? formatter.format(roundedValue) : zeroString;
//	    if (LOG.isDebugEnabled()) {
//	      LOG.debug("rawString: " + rawString + " - G[" + groupingSeparator + "] D[" + decimalSeparator + "]");
//	    }
		rawString = rawString.replaceAll("\\" + groupingSeparator, "");

		String beforeDelimiter = rawString.substring(0, rawString.indexOf(decimalSeparator));
		String afterDelimiter = rawString.substring(rawString.indexOf(decimalSeparator) + 1, rawString.length());
//	    if (LOG.isDebugEnabled()) {
//	      LOG.debug("beforeDelimiter[" + beforeDelimiter + "], afterDelimiter[" + afterDelimiter + "]");
//	    }

		// trim decimals
		afterDelimiter = StringUtil.substring(afterDelimiter, 0, decimals);
		afterDelimiter = StringUtil.rightPad(afterDelimiter, decimals, '0');

		String delimiter = "" + decimalFieldMetadata.getDecimalDelimiter();
		String result = beforeDelimiter + delimiter + afterDelimiter;
//	    if (LOG.isDebugEnabled()) {
//	      LOG.debug("result[" + result + "]");
//	    }
		return result;
	}

	protected String getNumberStrig(String string, DecimalFieldMetadata decimalFieldMetadata) {

		int decimals = decimalFieldMetadata.getDecimals();
		if (decimals > 0 && string.length() >= decimals) {
			String beforeDelimiter = string.substring(0, string.length() - decimals);
			String afterDelimiter = string.substring(string.length() - decimals, string.length());
			return beforeDelimiter + '.' + afterDelimiter;
		}
		return string;
	}

	@Override
	public String writeAsString(T t, FieldMetadata fileFieldMetadata) {
		return numberToString(t, fileFieldMetadata.getDecimalFieldMetadata());
	}

}
