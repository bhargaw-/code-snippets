package com.jpmc.fixed.format.util;

import static java.lang.String.format;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Objects;

import com.jpmc.fixed.format.annotation.BasicField;
import com.jpmc.fixed.format.annotation.BooleanField;
import com.jpmc.fixed.format.annotation.DateField;
import com.jpmc.fixed.format.annotation.DecimalField;
import com.jpmc.fixed.format.annotation.Record;
import com.jpmc.fixed.format.annotation.exception.FormatException;
import com.jpmc.fixed.format.model.BasicFieldMetadata;
import com.jpmc.fixed.format.model.BooleanFieldMetadata;
import com.jpmc.fixed.format.model.ClassMetadata;
import com.jpmc.fixed.format.model.DateFieldMetadata;
import com.jpmc.fixed.format.model.DecimalFieldMetadata;
import com.jpmc.fixed.format.model.FieldMetadata;

public class ClassMetadataUtil {

	private ClassMetadataUtil() {
	}

	public static ClassMetadata loadMetadata(Class<?> clazz) {

		Record record = clazz.getAnnotation(Record.class);
		if (record == null) {
			throw new FormatException(
					format("%s has to be marked with the record annotation to be loaded", clazz.getName()));
		}

		ClassMetadata classMetada = new ClassMetadata();

		classMetada.setClazz(clazz);
		classMetada.setHeader(record.header());
		classMetada.setRecord(record.record());
		classMetada.setFooter(record.footer());
		classMetada.setDeletemter(record.delemeter());
		classMetada.setPaddring(record.padding());

		FieldMetadata[] fieldsMetadata = Arrays.stream(clazz.getDeclaredFields())
				.map(field -> getFieldMetada(clazz, field)).filter(Objects::nonNull).toArray(FieldMetadata[]::new);

		classMetada.setFieldsFieldMetadata(fieldsMetadata);

		return classMetada;

	}

	private static FieldMetadata getFieldMetada(Class<?> clazz, Field field) {

		BasicField fixedField = field.getAnnotation(BasicField.class);

		if (fixedField == null) {
			return null;
		}

		PropertyDescriptor propertyDescriptor = null;
		String propertyName = field.getName();
		try {
			propertyDescriptor = new PropertyDescriptor(propertyName, clazz);
		} catch (IntrospectionException e) {
			throw new FormatException("Unknown property : " + propertyName, e);
		}

		Method readMethod = propertyDescriptor.getReadMethod();
		Method writeMethod = propertyDescriptor.getWriteMethod();

		if (readMethod == null || writeMethod == null) {
			return null;
		}

		FieldMetadata fieldMetadata = new FieldMetadata();
		fieldMetadata.setName(propertyName);
		fieldMetadata.setReadMethod(readMethod.getName());
		fieldMetadata.setWriteMethod(writeMethod.getName());
		fieldMetadata.setDataType(readMethod.getReturnType());
		fieldMetadata.setBasicFieldMetadata(getBasicFieldMetadata(field));
		fieldMetadata.setBooleanFieldMetadata(getBooleanFieldMetadata(field));
		fieldMetadata.setDateFieldMetadata(getDateFieldMetadata(field));
		fieldMetadata.setDecimalFieldMetadata(getDecimalFieldMetadata(field));

		return fieldMetadata;
	}

	private static BasicFieldMetadata getBasicFieldMetadata(Field field) {
		BasicField fixedField = field.getAnnotation(BasicField.class);
		BasicFieldMetadata fixedFieldMetadata = new BasicFieldMetadata();
		fixedFieldMetadata.setAlign(fixedField.align());
		fixedFieldMetadata.setLenght(fixedField.length());
		fixedFieldMetadata.setPosition(fixedField.position());
		fixedFieldMetadata.setPadding(fixedField.padding());

		return fixedFieldMetadata;
	}

	private static BooleanFieldMetadata getBooleanFieldMetadata(Field field) {

		BooleanField booleanField = field.getAnnotation(BooleanField.class);
		if (booleanField == null) {
			return null;
		}

		BooleanFieldMetadata metadata = new BooleanFieldMetadata();
		metadata.setFalseValue(booleanField.falseValue());
		metadata.setTrueValue(booleanField.trueValue());

		return metadata;
	}

	private static DecimalFieldMetadata getDecimalFieldMetadata(Field field) {

		DecimalField decimalField = field.getAnnotation(DecimalField.class);
		if (decimalField == null) {
			return null;
		}

		DecimalFieldMetadata metadata = new DecimalFieldMetadata();
		metadata.setDecimalDelimiter(decimalField.decimalDelimiter());
		metadata.setDecimals(decimalField.decimals());
		metadata.setRoundingMode(decimalField.roundingMode());

		return metadata;
	}

	private static DateFieldMetadata getDateFieldMetadata(Field field) {

		DateField dateField = field.getAnnotation(DateField.class);
		if (dateField == null) {
			return null;
		}

		DateFieldMetadata metadata = new DateFieldMetadata();
		metadata.setFormat(dateField.format());
		return metadata;
	}

}
