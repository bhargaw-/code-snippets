package com.jpmc.fixed.format.model;

public class DecimalFieldMetadata {

	private int decimals;

	private char decimalDelimiter;

	private int roundingMode;

	public int getDecimals() {
		return decimals;
	}

	public void setDecimals(int decimals) {
		this.decimals = decimals;
	}

	public char getDecimalDelimiter() {
		return decimalDelimiter;
	}

	public void setDecimalDelimiter(char decimalDelimiter) {
		this.decimalDelimiter = decimalDelimiter;
	}

	public int getRoundingMode() {
		return roundingMode;
	}

	public void setRoundingMode(int roundingMode) {
		this.roundingMode = roundingMode;
	}

	@Override
	public String toString() {
		return "DecimalFieldMetadata [decimals=" + decimals + ", " + ", decimalDelimiter=" + decimalDelimiter
				+ ", roundingMode=" + roundingMode + "]";
	}

}
