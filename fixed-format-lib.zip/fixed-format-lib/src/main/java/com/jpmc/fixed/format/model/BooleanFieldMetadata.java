package com.jpmc.fixed.format.model;

public class BooleanFieldMetadata {

	private String trueValue;
	private String falseValue;

	public String getTrueValue() {
		return trueValue;
	}

	public void setTrueValue(String trueValue) {
		this.trueValue = trueValue;
	}

	public String getFalseValue() {
		return falseValue;
	}

	public void setFalseValue(String falseValue) {
		this.falseValue = falseValue;
	}

	@Override
	public String toString() {
		return " [trueValue=" + trueValue + ", falseValue=" + falseValue + "]";
	}

}
