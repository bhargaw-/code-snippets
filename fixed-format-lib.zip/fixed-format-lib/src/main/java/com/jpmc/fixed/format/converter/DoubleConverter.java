package com.jpmc.fixed.format.converter;

import com.jpmc.fixed.format.model.FieldMetadata;

public class DoubleConverter extends DecimalConverter<Double> {

	@Override
	public Double writeAsObject(String t, FieldMetadata fileFieldMetadata) {
		String toConvert = getNumberStrig(t, fileFieldMetadata.getDecimalFieldMetadata());
		return Double.parseDouble("".equals(toConvert) ? "0" : toConvert);
	}
}
