package com.jpmc.fixed.format.model;

import java.util.Arrays;

public class ClassMetadata {

	private String header;
	private String footer;
	private String record;
	private String deletemter;
	private char paddring;
	private Class<?> clazz;
	private FieldMetadata[] fieldsFieldMetadata;

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public String getFooter() {
		return footer;
	}

	public void setFooter(String footer) {
		this.footer = footer;
	}

	public String getRecord() {
		return record;
	}

	public void setRecord(String record) {
		this.record = record;
	}

	public String getDeletemter() {
		return deletemter;
	}

	public void setDeletemter(String deletemter) {
		this.deletemter = deletemter;
	}

	public char getPaddring() {
		return paddring;
	}

	public void setPaddring(char paddring) {
		this.paddring = paddring;
	}
	
	public Class<?> getClazz() {
		return clazz;
	}
	
	public void setClazz(Class<?> clazz) {
		this.clazz = clazz;
	}

	public FieldMetadata[] getFieldsFieldMetadata() {
		return fieldsFieldMetadata;
	}

	public void setFieldsFieldMetadata(FieldMetadata[] fieldsFieldMetadata) {
		this.fieldsFieldMetadata = fieldsFieldMetadata;
	}

	@Override
	public String toString() {
		return "ClassMetadata [header=" + header + ", footer=" + footer + ", record=" + record
				+ ", deletemter=" + deletemter + ", paddring=" + paddring + ", fieldsFieldMetadata="
				+ Arrays.toString(fieldsFieldMetadata) + "]";
	}

}
