/*
 * Copyright 2004 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.jpmc.fixed.format.converter;

import java.math.BigDecimal;
import java.util.Date;

import com.jpmc.fixed.format.model.FieldMetadata;

/**
 * Formatter capable of formatting a bunch of known java standard library
 * classes. So far: {@link String}, {@link Integer}, {@link Short},
 * {@link Long}, {@link Date}, {@link Character}, {@link Boolean},
 * {@link Double}, {@link Float} and {@link BigDecimal}
 *
 *
 * @author Jacob von Eyben - http://www.ancientprogramming.com
 * @since 1.0.0
 */
public class TypeConverter {

//	public static Object convert(Class<?> target, String s) {
//
//		if (target.isAssignableFrom(Character.class) || target.isAssignableFrom(char.class)) {
//			return s.charAt(0);
//		}
//		if (target.isAssignableFrom(Boolean.class) || target.isAssignableFrom(boolean.class)) {
//			return Boolean.parseBoolean(s);
//		}
//		if (target.isAssignableFrom(Byte.class) || target.isAssignableFrom(byte.class)) {
//			return Byte.parseByte(s);
//		}
//		if (target.isAssignableFrom(Short.class) || target.isAssignableFrom(short.class)) {
//			return Short.parseShort(s);
//		}
//		if (target.isAssignableFrom(Integer.class) || target.isAssignableFrom(int.class)) {
//			return Integer.parseInt(s);
//		}
//		if (target.isAssignableFrom(Long.class) || target.isAssignableFrom(long.class)) {
//			return Long.parseLong(s);
//		}
//		if (target.isAssignableFrom(Float.class) || target.isAssignableFrom(float.class)) {
//			return Float.parseFloat(s);
//		}
//		if (target.isAssignableFrom(Double.class) || target.isAssignableFrom(double.class)) {
//			return Double.parseDouble(s);
//		}
//		if (target.isAssignableFrom(BigDecimal.class)) {
//			return new BigDecimal(s);
//		}
//		if (target.isAssignableFrom(String.class)) {
//			return s;
//		}
//		if (target.isAssignableFrom(Date.class)) {
//			return Date.from(Instant.parse(s));
//		}
//		throw new IllegalArgumentException("Don't know how to convert to " + target);
//	}

	public static String converter(Object object, FieldMetadata fieldMetadata) {
		
		Class<?> target = object.getClass();

		if (target.isAssignableFrom(Character.class) || target.isAssignableFrom(char.class)) {
//			System.out.println("CHAR");
			return new CharacterConverter().format((Character)object, fieldMetadata);
		}
		if (target.isAssignableFrom(Boolean.class) || target.isAssignableFrom(boolean.class)) {
//			System.out.println("BOOL");
			return new BooleanConverter().format((Boolean)object, fieldMetadata);
		}
		if (target.isAssignableFrom(Byte.class) || target.isAssignableFrom(byte.class)) {
//			System.out.println("BYTE");
			throw new UnsupportedOperationException("We are not supporting this format");
		}
		if (target.isAssignableFrom(Short.class) || target.isAssignableFrom(short.class)) {
//			System.out.println("SHORT");
			return new ShortConverter().format((Short)object, fieldMetadata);
		}
		if (target.isAssignableFrom(Integer.class) || target.isAssignableFrom(int.class)) {
//			System.out.println("INT");
			return new IntegerConverter().format((Integer)object, fieldMetadata);
		}
		if (target.isAssignableFrom(Long.class) || target.isAssignableFrom(long.class)) {
//			System.out.println("LONG");
			return new LongConverter().format((Long)object, fieldMetadata);
		}
		if (target.isAssignableFrom(Float.class) || target.isAssignableFrom(float.class)) {
//			System.out.println("FLOT");
			return new FloatConverter().format((Float)object, fieldMetadata);
		}
		if (target.isAssignableFrom(Double.class) || target.isAssignableFrom(double.class)) {
//			System.out.println("DOUBLE");
			return new DoubleConverter().format((Double)object, fieldMetadata);
		}
		if (target.isAssignableFrom(BigDecimal.class)) {
//			System.out.println("BigDecimal");
			return new BigDecimalConverter().format((BigDecimal)object, fieldMetadata);
		}
		if (target.isAssignableFrom(String.class)) {
//			System.out.println("String");
			return new StringConverter().format((String)object, fieldMetadata);
		}
		if (target.isAssignableFrom(Date.class)) {
//			System.out.println("Date");
			return new DateConverter().format((Date)object, fieldMetadata);
		}
		throw new IllegalArgumentException("Don't know how to convert to " + target);
	}

}
