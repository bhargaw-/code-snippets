package com.jpmc.fixed.format.util;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Objects;

import com.jpmc.fixed.format.converter.TypeConverter;
import com.jpmc.fixed.format.model.ClassMetadata;
import com.jpmc.fixed.format.model.Employee;
import com.jpmc.fixed.format.model.FieldMetadata;

public class FixedFormatService<T> {

	private final ClassMetadata classMeatadata;

	public FixedFormatService(Class<T> clazz) {
		this.classMeatadata = ClassMetadataUtil.loadMetadata(clazz);
	}

	public String writeAsString(T t) {

		Objects.requireNonNull(t, "object must not be null");

		StringBuilder sb = new StringBuilder();

		FieldMetadata[] fieldsFieldMetadata = classMeatadata.getFieldsFieldMetadata();

		for (FieldMetadata fieldMetadata : fieldsFieldMetadata) {
			Object propertyValue = readPropertyValue(fieldMetadata, t);
			String converter = TypeConverter.converter(propertyValue, fieldMetadata);
			System.out.println(converter);
			sb.append(converter);
		}

		return sb.toString();

	}
	
	
	
	

	private Object readPropertyValue(FieldMetadata fieldMeatMetadata, T t) {
		String readMethod = fieldMeatMetadata.getReadMethod();
		try {
			Method method = t.getClass().getMethod(readMethod);
			return method.invoke(t);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;

	}

	public static void main(String[] args) {

		FixedFormatService<Employee> service = new FixedFormatService<>(Employee.class);

		Employee e = new Employee();

//		e.setActive(true);
//		e.setConvertor(new BigDecimal("10"));
//		e.setDob(new Date());
//		e.setDeptNo((short) 10);
//		e.setJoindate(LocalDate.now());
//		e.setLoginTime(LocalDateTime.now());
//		e.setSalary(1000.00);
		e.setEmpId(1);
		e.setRateOfInterest(3.2F);
		e.setEmpName("Bhargav");

		System.out.println(service.writeAsString(e));

	}

}
