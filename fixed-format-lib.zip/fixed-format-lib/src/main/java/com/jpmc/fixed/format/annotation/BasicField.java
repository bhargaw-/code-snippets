package com.jpmc.fixed.format.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.FIELD })
public @interface BasicField {

	int position();

	int startIndex();

	int length();

	Align align() default Align.LEFT;

	char padding() default ' ';
}
