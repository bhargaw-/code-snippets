package com.jpmc.fixed.format.util;

import java.util.function.Function;



public class ConverterUtil {
	
//	private static final Map<Class<? extends Serializable>, Class<? extends Formatter<?>>> FORMATTERS = new HashMap<Class<? extends Serializable>, Class<? extends Formatter<?>>>();
//	
//	  static {
//		    FORMATTERS.put(String.class, StringFormatter.class);
//		    FORMATTERS.put(short.class, ShortFormatter.class);
//		    FORMATTERS.put(Short.class, ShortFormatter.class);
//		    FORMATTERS.put(int.class, IntegerFormatter.class);
//		    FORMATTERS.put(Integer.class, IntegerFormatter.class);
//		    FORMATTERS.put(long.class, LongFormatter.class);
//		    FORMATTERS.put(Long.class, LongFormatter.class);
//		    FORMATTERS.put(Date.class, DateFormatter.class);
//		    FORMATTERS.put(char.class, CharacterFormatter.class);
//		    FORMATTERS.put(Character.class, CharacterFormatter.class);
//		    FORMATTERS.put(boolean.class, BooleanFormatter.class);
//		    FORMATTERS.put(Boolean.class, BooleanFormatter.class);
//		    FORMATTERS.put(double.class, DoubleFormatter.class);
//		    FORMATTERS.put(Double.class, DoubleFormatter.class);
//		    FORMATTERS.put(float.class, FloatFormatter.class);
//		    FORMATTERS.put(Float.class, FloatFormatter.class);
//		    FORMATTERS.put(BigDecimal.class,  BigDecimalFormatter.class);
//		  }
	
	

	<T, R> R convert(T t, Function<T, R> convertFunction) {
		return convertFunction.apply(t);
	}
}
