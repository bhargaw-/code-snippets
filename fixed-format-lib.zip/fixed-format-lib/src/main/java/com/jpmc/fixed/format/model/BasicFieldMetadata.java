package com.jpmc.fixed.format.model;

import com.jpmc.fixed.format.annotation.Align;

public class BasicFieldMetadata {

	private int startIndex;
	private Align align;
	private int position;
	private int lenght;
	private char padding;
	
	public int getStartIndex() {
		return startIndex;
	}
	
	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}

	public Align getAlign() {
		return align;
	}

	public void setAlign(Align align) {
		this.align = align;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}

	public int getLenght() {
		return lenght;
	}

	public void setLenght(int lenght) {
		this.lenght = lenght;
	}

	public char getPadding() {
		return padding;
	}

	public void setPadding(char padding) {
		this.padding = padding;
	}

	@Override
	public String toString() {
		return " [align=" + align + ", position=" + position + ", lenght=" + lenght + ", padding=" + padding + "]";
	}

}
