package com.jpmc.fixed.format.model;

public class DateFieldMetadata {

	private String format;

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	@Override
	public String toString() {
		return " [format=" + format + "]";
	}

}
