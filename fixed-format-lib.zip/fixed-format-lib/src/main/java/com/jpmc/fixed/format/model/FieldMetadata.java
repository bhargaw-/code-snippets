package com.jpmc.fixed.format.model;

public class FieldMetadata {

	private String name;
	private String readMethod;
	private String writeMethod;
	private Class<?> dataType;
	private BasicFieldMetadata basicFieldMetadata;
	private BooleanFieldMetadata booleanFieldMetadata;
	private DateFieldMetadata dateFieldMetadata;
	private DecimalFieldMetadata decimalFieldMetadata;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getReadMethod() {
		return readMethod;
	}

	public void setReadMethod(String readMethod) {
		this.readMethod = readMethod;
	}

	public String getWriteMethod() {
		return writeMethod;
	}

	public void setWriteMethod(String writeMethod) {
		this.writeMethod = writeMethod;
	}

	public Class<?> getDataType() {
		return dataType;
	}

	public void setDataType(Class<?> dataType) {
		this.dataType = dataType;
	}

	public BasicFieldMetadata getBasicFieldMetadata() {
		return basicFieldMetadata;
	}

	public void setBasicFieldMetadata(BasicFieldMetadata basicFieldMetadata) {
		this.basicFieldMetadata = basicFieldMetadata;
	}

	public BooleanFieldMetadata getBooleanFieldMetadata() {
		return booleanFieldMetadata;
	}

	public void setBooleanFieldMetadata(BooleanFieldMetadata booleanFieldMetadata) {
		this.booleanFieldMetadata = booleanFieldMetadata;
	}

	public DateFieldMetadata getDateFieldMetadata() {
		return dateFieldMetadata;
	}

	public void setDateFieldMetadata(DateFieldMetadata dateFieldMetadata) {
		this.dateFieldMetadata = dateFieldMetadata;
	}

	public DecimalFieldMetadata getDecimalFieldMetadata() {
		return decimalFieldMetadata;
	}

	public void setDecimalFieldMetadata(DecimalFieldMetadata decimalFieldMetadata) {
		this.decimalFieldMetadata = decimalFieldMetadata;
	}

	@Override
	public String toString() {
		return "FieldMetadata [name=" + name + ", readMethod=" + readMethod + ", writeMethod=" + writeMethod
				+ ", dataType=" + dataType + ", basicFieldMetadata=" + basicFieldMetadata + ", booleanFieldMetadata="
				+ booleanFieldMetadata + ", dateFieldMetadata=" + dateFieldMetadata + ", decimalFieldMetadata="
				+ decimalFieldMetadata + "]";
	}

}
