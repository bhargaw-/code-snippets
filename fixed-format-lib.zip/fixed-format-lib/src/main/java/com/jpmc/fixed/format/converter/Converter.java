package com.jpmc.fixed.format.converter;

import com.jpmc.fixed.format.annotation.exception.FormatException;
import com.jpmc.fixed.format.model.FieldMetadata;

public interface Converter<T> {

	T parse(String value, FieldMetadata instructions) throws FormatException;

	String format(T value, FieldMetadata instructions) throws FormatException;

}
