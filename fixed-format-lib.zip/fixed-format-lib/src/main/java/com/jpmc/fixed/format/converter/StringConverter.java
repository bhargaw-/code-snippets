package com.jpmc.fixed.format.converter;

import com.jpmc.fixed.format.model.FieldMetadata;

public class StringConverter extends AbstractConverter<String> {

	@Override
	public String writeAsString(String t, FieldMetadata fileFieldMetadata) {
		return t;
	}

	@Override
	public String writeAsObject(String t, FieldMetadata fileFieldMetadata) {
		return t;
	}

}
