package com.jpmc.fixed.format.converter;

import com.jpmc.fixed.format.annotation.exception.FormatException;
import com.jpmc.fixed.format.model.BasicFieldMetadata;
import com.jpmc.fixed.format.model.FieldMetadata;

public abstract class AbstractConverter<T> implements Converter<T> {

	@Override
	public T parse(String value, FieldMetadata fieldMetadata) {
		if (value != null) {
			String planinString = removePadding(value, fieldMetadata.getBasicFieldMetadata());
			return writeAsObject(planinString, fieldMetadata);
		}
		return null;
	}

	@Override
	public String format(T value, FieldMetadata fieldMetadata) throws FormatException {
		String srt = writeAsString(value, fieldMetadata);
		return applyPadding(srt, fieldMetadata.getBasicFieldMetadata());
	}

	String removePadding(String paddedString, BasicFieldMetadata basicFieldMetadata) {
		return basicFieldMetadata.getAlign().remove(paddedString, basicFieldMetadata.getPadding());
	}

	String applyPadding(String plainString, BasicFieldMetadata basicFieldMetadata) {
		return basicFieldMetadata.getAlign().apply(plainString, basicFieldMetadata.getLenght(),
				basicFieldMetadata.getPadding());
	}

	public abstract String writeAsString(T t, FieldMetadata fileFieldMetadata);

	public abstract T writeAsObject(String t, FieldMetadata fileFieldMetadata);

}