package com.jpmc.fixed.format.converter;

import com.jpmc.fixed.format.annotation.exception.FormatException;
import com.jpmc.fixed.format.model.BooleanFieldMetadata;
import com.jpmc.fixed.format.model.FieldMetadata;
import com.jpmc.fixed.format.util.StringUtil;

public class BooleanConverter extends AbstractConverter<Boolean> {

	@Override
	public String writeAsString(Boolean t, FieldMetadata fileFieldMetadata) {
		BooleanFieldMetadata booleanFieldMetadata = fileFieldMetadata.getBooleanFieldMetadata();
		String result = booleanFieldMetadata.getFalseValue();
		if (t != null) {
			result = t ? booleanFieldMetadata.getTrueValue() : booleanFieldMetadata.getFalseValue();
		}
		return result;
	}

	@Override
	public Boolean writeAsObject(String t, FieldMetadata fileFieldMetadata) {
		Boolean result = false;
		if (!StringUtil.isEmpty(t)) {
			BooleanFieldMetadata booleanFieldMetadata = fileFieldMetadata.getBooleanFieldMetadata();
			if (booleanFieldMetadata.getTrueValue().equals(t)) {
				result = true;
			} else if (booleanFieldMetadata.getFalseValue().equals(t)) {
				result = false;
			} else {
				throw new FormatException("Could not convert string[" + t + "] to boolean value");
			}
		}
		return result;
	}

}
