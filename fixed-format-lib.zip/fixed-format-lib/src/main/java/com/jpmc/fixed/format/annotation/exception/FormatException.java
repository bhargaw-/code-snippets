package com.jpmc.fixed.format.annotation.exception;

public class FormatException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -563419936854635659L;

	public FormatException(String s) {
		super(s);
	}

	public FormatException(String s, Throwable throwable) {
		super(s, throwable);
	}
}
