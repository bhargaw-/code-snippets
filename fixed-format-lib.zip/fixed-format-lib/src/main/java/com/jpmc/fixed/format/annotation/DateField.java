package com.jpmc.fixed.format.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.FIELD })
public @interface DateField {

	public static final String SHORT = "yyyy-MM-dd";
	public static final String MEDIUM_PATTERN = "yyyy-MM-dd";
	public static final String LONG_PATTERN = "yyyy-MM-dd";

	String format() default SHORT;
	
}
