package org.fixedlength.record.converter.service;

import org.fixedlength.record.converter.model.AbstractMetadata;
import org.fixedlength.record.converter.model.RecordMetadata;

public class ObjectToStringConverterService<T> extends AbstractMetadata<T>
        implements IRecordConverter<T, String> {

    public ObjectToStringConverterService(Class<T> fixedRecordClass) {
        this(fixedRecordClass, null);
    }

    public ObjectToStringConverterService(Class<T> fixedRecordClass, IRecordMetadata<T> metadata) {
        super(fixedRecordClass, metadata);
    }

    @Override
    public String convert(T source) {
        RecordMetadata fixedRecordMetadata = this.getFixedRecordMetadata();
        return null;
    }
}
