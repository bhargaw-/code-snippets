package org.fixedlength.record.converter.model;

import java.util.Collections;
import java.util.List;

public class RecordMetadata<T> {

    private String headPrefix;
    private String tailPrefix;
    private String recordPrefix;
    private String delimiter;
    private char padding;
    private Class<T> type;
    private List<FieldMetadata<?>> fieldMetadataList;

    public RecordMetadata(String headPrefix, String tailPrefix,
                          String recordPrefix, String delimiter,
                          char padding, Class<T> type) {

        this.headPrefix = headPrefix;
        this.tailPrefix = tailPrefix;
        this.recordPrefix = recordPrefix;
        this.delimiter = delimiter;
        this.padding = padding;
        this.type = type;
        fieldMetadataList = Collections.emptyList();
    }

    public String getHeadPrefix() {
        return headPrefix;
    }

    public String getTailPrefix() {
        return tailPrefix;
    }

    public String getRecordPrefix() {
        return recordPrefix;
    }

    public String getDelimiter() {
        return delimiter;
    }

    public char getPadding() {
        return padding;
    }

    public Class<T> getType() {
        return type;
    }

    public List<FieldMetadata<?>> getFieldMetadataList() {
        return fieldMetadataList;
    }

    public void setFieldMetadataList(List<FieldMetadata<?>> fieldMetadataList) {
        this.fieldMetadataList = fieldMetadataList;
    }

    @Override
    public String toString() {
        return "RecordMetadata{" +
                "headPrefix='" + headPrefix + '\'' +
                ", tailPrefix='" + tailPrefix + '\'' +
                ", recordPrefix='" + recordPrefix + '\'' +
                ", delimiter='" + delimiter + '\'' +
                ", padding=" + padding +
                ", type=" + type +
                ", fieldMetadataList=" + fieldMetadataList +
                '}';
    }
}
