package org.fixedlength.record.converter.util;

import org.fixedlength.record.converter.annotation.FixedRecord;
import org.fixedlength.record.converter.exception.ConverterException;
import org.fixedlength.record.converter.service.IRecordMetadata;
import org.fixedlength.record.converter.service.DelimiterRecordMetadataService;
import org.fixedlength.record.converter.service.FixedRecordMetadataService;

public class CommonsUtil {

    private CommonsUtil() {
    }

    public static void validate(Object object, String errorMessage) {
        if (object == null) {
            throw new ConverterException(errorMessage);
        }
    }

    public static<T> IRecordMetadata<T> getIRecordMetadataInstance(Class<T> fixedRecordClass){
        FixedRecord fixedRecord = getFixedRecord(fixedRecordClass);
        final String delimiter = fixedRecord.delimiter();
        IRecordMetadata<T> iRecordMetadata;
        if (FixedRecord.DEFAULT_STRING_VALUE.equals(delimiter)) {
            iRecordMetadata = new FixedRecordMetadataService<>();
        } else {
            iRecordMetadata = new DelimiterRecordMetadataService<>();
        }
        return iRecordMetadata;
    }

    private static  <T> FixedRecord getFixedRecord(Class<T> fixedRecordClass){
        CommonsUtil.validate(fixedRecordClass, "fixedRecordClass should not be null");
        FixedRecord fixedRecord = fixedRecordClass.getAnnotation(FixedRecord.class);
        CommonsUtil.validate(fixedRecord, String.format(
                "%s is not annotated with @FixedRecord annotation.",fixedRecordClass.getName()));
        return fixedRecord;
    }
}
