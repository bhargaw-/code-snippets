package org.fixedlength.record.converter.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface DecimalField {

    int DECIMALS = 2;

    String DECIMAL_DELIMITER = ".";

    int decimals() default DECIMALS;

    String decimalDelimiter() default DECIMAL_DELIMITER;
}
