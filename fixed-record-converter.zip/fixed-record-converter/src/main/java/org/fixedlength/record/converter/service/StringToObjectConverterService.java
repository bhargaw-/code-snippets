package org.fixedlength.record.converter.service;

import org.fixedlength.record.converter.model.AbstractMetadata;

public class StringToObjectConverterService<T> extends AbstractMetadata<T>
        implements IRecordConverter<String, T> {

    public StringToObjectConverterService(Class<T> fixedRecordClass) {
        this(fixedRecordClass, null);
    }

    public StringToObjectConverterService(Class<T> fixedRecordClass, IRecordMetadata<T> metadata) {
        super(fixedRecordClass, metadata);
    }

    @Override
    public T convert(String source) {
        return null;
    }
}
