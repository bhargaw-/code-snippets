package org.fixedlength.record.converter.model;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;

public class FieldMetadata<S> {
    private int position;
    private int length;
    private String delimiter;
    private String fieldName;
    private String readMethod;
    private String writeMethod;
    private Class<S> type;
    private Map<String, String> metadata = Collections.emptyMap();

    public FieldMetadata(int position, int length, String delimiter, String fieldName,
                         String readMethod, String writeMethod, Class<S> type) {
        this.position = position;
        this.length = length;
        this.delimiter = delimiter;
        this.fieldName = fieldName;
        this.readMethod = readMethod;
        this.writeMethod = writeMethod;
        this.type = type;
    }

    public int getPosition() {
        return position;
    }

    public int getLength() {
        return length;
    }

    public String getDelimiter() {
        return delimiter;
    }

    public String getFieldName() {
        return fieldName;
    }

    public String getReadMethod() {
        return readMethod;
    }

    public String getWriteMethod() {
        return writeMethod;
    }

    public Class<S> getType() {
        return type;
    }

    public Map<String, String> getMetadata() {
        return metadata;
    }

    public void setMetadata(Consumer<Map<String, String>> metadataConsumer) {
        metadata = metadata.isEmpty() ? new LinkedHashMap<>() : metadata;
        metadataConsumer.accept(metadata);
    }

    @Override
    public String toString() {
        return "FieldMetadata{" +
                "position=" + position +
                ", length=" + length +
                ", delimiter='" + delimiter + '\'' +
                ", type=" + type +
                ", metadata=" + metadata +
                '}';
    }
}
