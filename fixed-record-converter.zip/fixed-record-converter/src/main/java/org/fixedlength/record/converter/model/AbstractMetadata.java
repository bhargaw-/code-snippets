package org.fixedlength.record.converter.model;

import org.fixedlength.record.converter.service.IRecordMetadata;
import org.fixedlength.record.converter.util.CommonsUtil;

public abstract class AbstractMetadata<T> {

    private final Class<T> fixedRecordClass;

    private final IRecordMetadata<T> recordMetadata;

    public AbstractMetadata(final Class<T> fixedRecordClass,
                            IRecordMetadata<T> recordMetadata) {
        CommonsUtil.validate(fixedRecordClass, "fixedRecordClass must not be null");

        if (recordMetadata == null) {
            recordMetadata = CommonsUtil.getIRecordMetadataInstance(fixedRecordClass);
        }
        this.fixedRecordClass = fixedRecordClass;
        this.recordMetadata = recordMetadata;
    }

    public Class<T> getFixedRecordClass() {
        return fixedRecordClass;
    }

    public RecordMetadata<T> getFixedRecordMetadata() {
        return this.recordMetadata
                .getRecordMetadata(this.fixedRecordClass);
    }
}
