package org.fixedlength.record.converter.service;

import org.fixedlength.record.converter.model.RecordMetadata;

public interface IRecordMetadata<T> {
    RecordMetadata<T> getRecordMetadata(Class<T> fixedRecordClass);
}
