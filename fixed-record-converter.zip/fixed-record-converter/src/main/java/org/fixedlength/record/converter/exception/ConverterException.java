package org.fixedlength.record.converter.exception;

public class ConverterException extends RuntimeException {

	private static final long serialVersionUID = -563419936854635659L;

	public ConverterException(String s) {
		super(s);
	}

	public ConverterException(String s, Throwable throwable) {
		super(s, throwable);
	}
}
