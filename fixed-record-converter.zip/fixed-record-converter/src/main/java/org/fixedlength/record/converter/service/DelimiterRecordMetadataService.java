package org.fixedlength.record.converter.service;

import org.fixedlength.record.converter.model.RecordMetadata;

public class DelimiterRecordMetadataService<T> implements IRecordMetadata<T> {
    @Override
    public RecordMetadata<T> getRecordMetadata(Class<T> fixedRecordClass) {
        return null;
    }
}
