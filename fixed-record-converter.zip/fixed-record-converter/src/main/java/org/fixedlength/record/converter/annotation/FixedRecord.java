package org.fixedlength.record.converter.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface FixedRecord {

    String DEFAULT_STRING_VALUE = "";

    char DEFAULT_CHAR_VALUE = ' ';

    String headPrefix() default DEFAULT_STRING_VALUE;

    String recordPrefix() default DEFAULT_STRING_VALUE;

    String tailPrefix() default DEFAULT_STRING_VALUE;

    String delimiter() default DEFAULT_STRING_VALUE;

    char padding() default DEFAULT_CHAR_VALUE;
}
