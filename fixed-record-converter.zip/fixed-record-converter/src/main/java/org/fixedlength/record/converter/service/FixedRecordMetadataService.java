package org.fixedlength.record.converter.service;

import org.fixedlength.record.converter.model.RecordMetadata;

public class FixedRecordMetadataService<T> implements IRecordMetadata<T> {

    @Override
    public RecordMetadata<T> getRecordMetadata(Class<T> targetClass) {
        return null;
    }
}
