package org.fixedlength.record.converter.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface BooleanField {

    String TRUE_VALUE = "T";

    String FALSE_VALUE = "F";

    String trueValue() default TRUE_VALUE;

    String falseValue() default FALSE_VALUE;
}
