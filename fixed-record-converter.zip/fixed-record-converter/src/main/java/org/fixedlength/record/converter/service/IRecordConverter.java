package org.fixedlength.record.converter.service;

public interface IRecordConverter<T, R> {
    R convert(T source);
}
