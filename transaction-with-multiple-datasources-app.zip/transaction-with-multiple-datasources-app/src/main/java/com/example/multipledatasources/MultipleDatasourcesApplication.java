package com.example.multipledatasources;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

import com.example.datasource.one.service.PrimaryService;
import com.example.datasource.two.service.SecondryService;

@SpringBootApplication
@ComponentScan("com.example.datasource")
@EnableAutoConfiguration(exclude = { DataSourceAutoConfiguration.class })
//@EnableTransactionManagement
public class MultipleDatasourcesApplication implements CommandLineRunner{
	
	@Autowired
	private PrimaryService primaryService;
	
	@Autowired
	private SecondryService secondryService;

	public static void main(String[] args) {
		SpringApplication.run(MultipleDatasourcesApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		System.out.println("Inside the run method");
		
		try{
			primaryService.dataProcessOne();
		}catch (Exception e) {
			System.out.println(e.getMessage() + " From One");
		}
		
		try{
			secondryService.dataProcessTwo();
		}catch (Exception e ) {
			System.out.println(e.getMessage() + " From Two");
		}
		
		System.out.println("Execution completed");
	}
	
	
	
	
	
}
