package com.example.datasource.one.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.datasource.model.User;

@Repository
public interface PrimaryUserRepo extends JpaRepository<User, Integer> {
	
}
