package com.example.datasource.two.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.datasource.two.repo.SecondryUserRepo;
import com.example.datasource.util.DataUtil;

@Service
public class SecondryService {
	
	@Autowired
	private SecondryUserRepo secondryUserRepo;
	
	//@Transactional(rollbackOn = Exception.class, value = TxType.REQUIRED)
	@Transactional("secondryTransactionManager")
	public void dataProcessTwo() {
		secondryUserRepo.saveAll(DataUtil.prepareData());
		
		//throw new RuntimeException("From secondry service");
	}
	

}
