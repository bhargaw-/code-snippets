package com.example.datasource.two;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
//@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "com.example.datasource.two.repo", 
						entityManagerFactoryRef = "secondryEntityManager", 
						transactionManagerRef = "secondryTransactionManager")
public class DataSourceTwoConfiguration {
	
	@Bean("secondryDataSourceProperties")
	@ConfigurationProperties(prefix="spring.secondry.datasource")
	DataSourceProperties dataSourceOneProperties() {
		return new DataSourceProperties();
	}
	
	@Bean("secondryDatasource")
	DataSource dataSource() {
		return dataSourceOneProperties().initializeDataSourceBuilder().build();
	}

    @Bean(name = "secondryEntityManager")
	@PersistenceContext(unitName = "secondry")
	LocalContainerEntityManagerFactoryBean entityManagerFactoryBean(EntityManagerFactoryBuilder builder) {
		return builder.dataSource(dataSource())
				.persistenceUnit("secondry")
				.properties(jpaProperties())
				.packages("com.example.datasource.model")
				.build();
	}

	@Bean("secondryTransactionManager")
	PlatformTransactionManager transactionManager(
			@Qualifier("secondryEntityManager") EntityManagerFactory entityManagerFactory) {
		return new JpaTransactionManager(entityManagerFactory);
	}
	
	
	
	
	private Map<String, Object> jpaProperties() {
        Map<String, Object> props = new HashMap<>();
        props.put("hibernate.show_sql", true);
        props.put("hibernate.hbm2ddl.auto", "create");
        return props;
    }
	
	/*@Bean("secondryTransactionManager")
	PlatformTransactionManager transactionManager() {
		return new JtaTransactionManager();
	}*/
	

}
