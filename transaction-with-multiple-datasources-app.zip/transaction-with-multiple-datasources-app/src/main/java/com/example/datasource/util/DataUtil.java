package com.example.datasource.util;

import java.util.Arrays;
import java.util.List;

import com.example.datasource.model.User;

public class DataUtil {
	
	public static List<User> prepareData(){
		return Arrays.asList(new User(1, "Bhargav2", 31),
				new User(2, "Bhargav2", 32),
				new User(3, "Bhargav3", 33));
	}

}
