package com.example.datasource.one.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.datasource.one.repo.PrimaryUserRepo;
import com.example.datasource.util.DataUtil;

@Service
public class PrimaryService {
	
	@Autowired
	private PrimaryUserRepo primaryUserRepo;
	
	//@Transactional(rollbackOn = Exception.class, value = TxType.REQUIRED)
	@Transactional("primaryTransactionManager")
	public void dataProcessOne() {
		primaryUserRepo.saveAll(DataUtil.prepareData());
		
		//throw new RuntimeException("From primary service");
	}
	

}
